Lefty's Sims "Lesser Dark Side" Flamingo.

Half all motives by viewing this object.
priced at $12
under misc. and deco.
Black with yellow beak and green L on side.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
