Lefty's Sims Gnohmon's Grow Sofa.

A single-tile chair. If you put two next to each other, they appear to turn into a two-tile loveseat!

Guess what happens if you put three side by side? That's right, they become a three-tile sofa! Have you ever wanted a four-tile sofa? Five? Six? How about a 48-tile sofa? It's up to you! No cuddling, no naps, and the "sofa" doesn't have its own group talk.


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.


Original Object from

http://mistymage.com/gnohmongoodies/furniture.html