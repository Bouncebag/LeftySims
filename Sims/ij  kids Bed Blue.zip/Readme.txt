Lefty's Sims IJ Reservable kids bed in Blue.

Reservable[1] kids bed.  Added feature that strongly encourages (but does not force) children to go to bed soon after 7pm, and to go back to bed eventually of their own accord if they are woken in the night.  "Nice" parents choose to tuck their kids in most nights, and there is a selectable option to do so (option disappears once child has already been tucked in).

[1]Single owner object.  Only a family member(child) may reserve.  Object can also be left free for all to use.

Made to match our blue bed set.

Oringal object by Inge Jones of simlogical.com

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
