"The Deiter" Loveseat  by Werkbunnst

Made to accompany our "Von Braun" recliner,
this Bauhaus inspired loveseat has been redesigned by a highly disciplined team of young, Swiss, ergonomic researchers.
"Sitting on this loveseat makes you feel like the King of Comfort!", exclaimed one scientist during final testing.
Swiss pearwood frame. Fully aniline dyed leather. 

Dolce Tutti Frutti Loveseat

Unique. Rigorous. Contemporary design. Extraordinary comfort. Chiclettina loveseats represent the apogee of authentic exclusiveness and creative hegemony.
Shell is molded polyurethane foam. Seat cushions are down-filled poly-core and pressed Llama wool. Legs are polished bubunga wood.
Manufacturer: SimCity Loveseat Corp   Designer: Lefty Sims

SimSafari Loveseat

Go wild with this latest addition to our lounge furniture collection. Synthetic zebra-hide and black damask are used to create a unique,
asymmetrical look that's right on the crest of the current retro-design wave.
Whether you and your guests are napping, watching TV or just relaxing,
the SimSafari will certainly be the center of attention all night long.
No animals were harmed in the production of this loveseat except an human-as-thick-as-an-ape called Joe who made it.....

"Red Matter" Loveseat from Studio Lefty

" Not Mass-produced junk,"THESE custom Red Matter sofas are DEFINED by their obviously labor intensive construction, museum-like appearance and sensuous red velvet." Lovely Retro Red colour, sure too get your pulse PUMPING

"Red Matter" Chair from Studio Lefty

Defined simply as Retro Red

__________________________
Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

Place the .far file in your Sims\Downloads folder.



Deiter, Red Matter and dolce based on Luxuriare loveseat
simsafari based on Contempto Loveseat
Red Matter Chair based on Frogg chair

