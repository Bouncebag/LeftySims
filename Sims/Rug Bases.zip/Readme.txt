Lefty Sims Rug Bases

These rugs are white.all have 4 Room impact.


Feel free to distribute. but do include LeftySims.txt.

if you use them as bases, please put "Base By Lefty Sims" in the object description.

Thank you.

Lefty Sims

http://uk.groups.yahoo.com/group/lefty_sims