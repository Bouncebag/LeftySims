Extract 
B001MCChdmed_browncoat.bmp
to /The Sims/Gamedata/Skins

to veiw a screenshot of it look at
Mediumskin browncoat.bmp
also included in this download


Uses a Maxis mesh. Head NOT included.

Created by Looroll, Main admin for http://challengingideas.com


Now Avalible At my Yahoo Group

http://uk.groups.yahoo.com/group/lefty_sims/


