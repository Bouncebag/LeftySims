Cowch Blue Lounger

Rare blue beef cows from middle peru are cultivated for there distinct colours, the meat from one of these cows is meant to bring luck and magic, however the skin is unknown.... anyway it looks good so who cares and whats more this sofa is not even real leather.....

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.

all priced at $1114
