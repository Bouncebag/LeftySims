Lefty's Sims Buyable Gnome+Gargoyle.

Fed up of having to buy a table to make Gnomes and Gargoyles? fed up of having to WORK to get them? well dont be fed up any longer. thanks to Lefty sims. The Gnome (LL) and Gargoyle(MM) are now buyable

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
