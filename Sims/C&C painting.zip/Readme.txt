Lefty's Sims C&C enterprises Painting.

Show your support for C&C enterprises with this painting. Cloned from "Still Life, Drapery and Crumbs" Room 9.  created by Lewis Wright frm Lefty Sims  (http://uk.groups.yahoo.com/group/lefty_sims) as a tribute to C&C enterprises http://c-and-c-enterprises.com

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
