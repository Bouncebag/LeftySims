Lefty Sims  Pencil Colour Wheel .

Place Wall in Gamedata\Walls

Price $1

Downloaded from
http://uk.groups.yahoo.com/group/lefty_sims/