Lefty's Sims Moncello Door Frame.

Moncello Door, without the door. Just the frame.
priced at $150
under doors

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
