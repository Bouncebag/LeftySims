Lefty Sims Wonder-Velvet floor .

Place Floor in Gamedata\Floors

Price $1

Downloaded from
http://uk.groups.yahoo.com/group/lefty_sims/