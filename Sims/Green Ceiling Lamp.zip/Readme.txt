Lefty's Sims Green Ceiling Lamp.

Santa Baena Ceiling Lamp in Green.

Also comes in Permalamp variaty

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
