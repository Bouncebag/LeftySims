Lefty Sims Emerald Rug and Floor.

Place Rug in \Downloads
Place Floor in Gamedata\Floors


Downloaded from
http://uk.groups.yahoo.com/group/lefty_sims/