Lefty's Sims "Sunny Side" Flamingo.Ver. 2

Max out all motives by viewing this object.
priced at $12
under misc. and deco.
Light Blue with yellow beak.
Please Replace oringinal. due to a programing error

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
