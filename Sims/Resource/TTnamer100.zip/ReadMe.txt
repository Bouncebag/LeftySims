1. Introduction
The Townie and Tourists Name Editor is a simple utility that allows you to edit the default names of Townies (Hot Date) and Tourists (Vacation). The name lists edited with this program are used by The Sims when new townies and tourists are first created. These changes are not applied retroactively to existing townies and tourists. 

2. Legal Disclaimer

The software is provided strictly on an "as-is" basis, without any warranties of any kind, whether expressed or implied, including without limitation any warranties of merchantability, fitness for a particular purpose, non-infringement or compatibility with your computer hardware or software. The author has no liability of any kind or nature in connection with your use of the software (including without limitation liability for any consequential or incidental damages), and the entire risk of use (including without limitation any damage to your computer hardware or software) resides with you.

3. Installation

The program can be run from any folder. On my machine I have it installed in:
C:\games\maxis\the sims\programs\TTnamer

The program requires the Visual Basic 6 runtime files. The VB 6 runtime files may be downloaded from the following locations:
http://www.softwarepatch.com/windows/vbrun6.html
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe

You may already have the VB 6 runtime files on your computer. No additional files are required by the program.

4. Operation

The program loads the data file from The Sims automatically at program start up. The data file live.IFF is backed up as the file original_live.IFF the first time the program is run. Any changes made with the editor can be undone by deleting the modified live.IFF file and renaming the original_live.IFF to be live.IFF.

There are seven different name lists that can be edited with the program. The option button group in the Name List Being Edited frame is used to select the list to edit. When a list is selected the names on that list are displayed in the list box at the bottom of the main window.

To edit a name simply click on the name in the list. The name will be copied to the name editing text box and the cursor will go there as well. Simply type in the new name. The name will change in the editing text box and in the list.

All changes made to the names will be stored in memory until you are ready to save the entire file. Click on the Save button or use the Save menu option on the File menu to save your changes to the live.IFF file.

5. Support

You can find the Lot Manager support forum at:
http://support.simwardrobe.com

Please post in the Miscellaneous Small Programs forum when reporting problems with the Townie and Tourist Name Editor.


----------
Copyright (C) 2002 James A. Sausville. All rights reserved.
http://www.simwardrobe.com