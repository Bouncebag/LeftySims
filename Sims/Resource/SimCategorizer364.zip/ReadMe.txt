1. Introduction

SimCategorizer is a program that will allow you to re-categorize your objects for use with the new Hot Date sub-categories. The program also allows you to flag the objects for use downtown (by selecting a downtown category). The existing catalog information (room and function flags) may also be changed.


2. Legal Disclaimer

The software is provided strictly on an "as-is" basis, without any warranties of any kind, whether expressed or implied, including without limitation any warranties of merchantability, fitness for a particular purpose, non-infringement or compatibility with your computer hardware or software. The author has no liability of any kind or nature in connection with your use of the software (including without limitation liability for any consequential or incidental damages), and the entire risk of use (including without limitation any damage to your computer hardware or software) resides with you.


3. Installation

SimCategorizer should be installed into a directory all by itself. Create a directory under The Sims, copy the file to and run it. It doesn't get any easier than that.

The program requires Visual Basic 6 runtime files. The VB 6 runtime files may be downloaded from the following location:
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe

No additional files are required by SimCategorizer.


4. Using SimCategorizer

DO NOT USE THIS PROGRAM WHILE RUNNING THE SIMS OR T-MOG!

The first thing that you need to do is select a directory. The directory selection list is in the upper left corner of the main window. SimCategorizer will remember the last directory selected and will display it the next time you use the program. Selecting a directory causes the object selection panel (the giant square on the right) to populate with the objects located in the selected directory.

The object selection panel displays the image and name of each object in the selected directory. If there are more than 49 objects in the selected directory (both housed and unhoused), the objects will be displayed on multiple pages. The [Previous] and [Next] buttons below the object selection panel allow you to change the page displayed. The current page and number of pages is displayed in the text box between the [Previous] and [Next] buttons. The currently selected object is indicated by a flashing white rectangle. Clicking on a object's image selects that object.

A question mark icon may be displayed in place of the image for some objects. An "X" on a red background will be displayed for objects that can not be loaded. Please see the known issues section for details on these anomalies.

Once an object is selected the object's filename is displayed in the Selected Object File box. The objects catalog name, image and description will appear in the Selected Object Details box. Clicking the [Edit Object] button will load the selected object and display the edit object window. Double clicking an object's image in the selection panel will select the object and cause it to be loaded immediately.

Note: SimCategorizer is only able to see objects in the \Downloads, \GameData\UserObjects and \GameData\Objects directories. The program can see objects in directories one level beneath these directories as well. (i.e. \Downloads\MyObjects).

Changing an Objects Name and Description

The name and description of an object appear in editable text boxes. Any changes to text in these boxes will be made to the object when it is saved.

Changing an Object's Price

The price of an object can be changed by entering a new value in the price box. The maximum price of an object 32767 simoleans.

Changing an Object's Room Flags

The room flags determine where the object will show up in the catalog when you enter buy mode and view objects by room. The primary function flag (left function list box) determines the room sub-category. You may select multiple room flags by holding down the Control key when selecting rooms.

Changing an Object's Build Mode Flags

The build mode flags determine where the object will show up in the catalog when in build mode. Setting the build mode flag to None will cause an object to show up in buy mode if the other catalog flags (room and function) are set. 

Changing and Object's Downtown Flags

In order for an object to show up downtown, the downtown category must be set. Conversely, clearing the downtown category will prevent an object from showing up downtown. The downtown object's sub-category is determined by the primary function flag (left function list box). You may select multiple downtown categories by holding down the Control key when selecting downtown categories. (Dining chairs are defined this way by Maxis.)

Changing and Object's Vacation Flags

In order for an object to show up on Vacation Island, the vacation category must be set. Conversely, clearing the vacation category will prevent an object from showing up on Vacation Island. The vacation object's sub-category is determined by the primary function flag (left function list box). You may select multiple vacation categories by holding down the Control key when selecting vacation categories. (Dining chairs are defined this way by Maxis.)

(The above also applies to Unleashed, Superstar and Makin Magic. Every expansion pack has it's own flag that needs to be set in order for the object to show up in the packs special areas.)

Changing an Object's Function Flags

The function flags determine where the object will show up in the catalog when you enter buy mode and view objects by function. The primary function flag acts as a subcategory flag for the room and downtown flags. The function subcategory flag determines the subcategory of an object when in buy mode at home only. The function subcategory flag has no effect downtown. You may select multiple function flags by holding down the Control key when selecting function categories and subcategories.

Other Features.

The [Clear All Flags] buttons will reset all category flags to zero. This is required if you want an object to show up only in the downtown.

If you double click on the objects image in the edit object window the object errata dialog will appear. This window displays the object's internal label along with it's object ID and magic cookie.

Working With FAR Files

Version 3 of SimCategorizer allows you to re-categorize objects in FAR files. There is a option button group on the main window that allows you to work with FAR files instead of folders. It is located above the folder (and FAR file) list box.

You can not change the name or description of objects within FAR files. Editing the categories of objects in FAR files is identical to editing objects in folders.

Support For Read Only IFF Files

Some people have begun to use read only IFF files in place of FAR files. Version 3 of SimCategorizer allows you to make an objects IFF file read only by checking the "Make IFF File Read Only" check box on the Edit Object window.

On the tools menu there is now an option to make all IFF files in a folder read only or writable.

5. Known Issues

Object Image May Be Question Mark

Some object may not have an identifiable catalog image. The object may not contain an image or the image may not be labeled. This is more annoying that anything else. It's also quite rare.

Object Image May Be a Capital Letter "X"

There are some objects that produce errors in the IFF read routines. These objects have an "X" displayed for their image in SimCategorizer. The program can not re-categorize these objects as they can not be successfully loaded by the program.

Primary OBJD Segment Not Found Message.
There are a few objects that seem to lack a primary OBJD segment. If the primary OBJD segment can not be located there is no way to change the catalog bytes. Objects that create this message cannot be re-categorized by the program.

Some Objects Never Show Up In Catalog

Some objects that aren't suppose to show up in the catalog (fire, etc.) still don't show up after being categorized. There are obviously some bits that I'm unaware of. Maybe in the next version.

Some Objects Don't Work Downtown

Many objects aren't supposed to work downtown. Some objects like stoves, refrigerators, bubble makers and dishwashers need to be re-cloned. In order for objects to work downtown, they need to be made "useable by visitors". Bill Simser's Menu Editor program allows you to do just that. I don't endorse it or recommend it and I can't support it. You can find it here:
http://blueprint.thesimsresource.com/


6. Support

You can find the SimCategorizer support forum at:
http://support.simwardrobe.com
