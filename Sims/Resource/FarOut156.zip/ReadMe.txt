1. Introduction

I created FAR Out as a simple way to make FAR files for The Sims. I had tried to use Bill Simser's Far Edit for this task, but I discovered that it did not work correctly. Far Edit added the actual path to your file, including the drive specification. Files created this way are unusable by The Sims.

FAR Out will allow you to:
-  create new FAR files
-  add files to existing FAR files
-  delete files from existing FAR files
-  extract files from FAR files
-  extract BMF files from FAR files and convert them to SKN files


2. Legal Disclaimer

The software is provided strictly on an "as-is" basis, without any warranties of any kind, whether expressed or implied, including without limitation any warranties of merchantability, fitness for a particular purpose, non-infringement or compatibility with your computer hardware or software. The author has no liability of any kind or nature in connection with your use of the software (including without limitation liability for any consequential or incidental damages), and the entire risk of use (including without limitation any damage to your computer hardware or software) resides with you.


3. Installation

FAR Out should be installed into a directory all by itself. 

The program requires Visual Basic 6 runtime files. You may already have the runtime files on your computer. The VB 6 runtime files may be downloaded from the following locations:
http://www.tweakfiles.com/misc/vb6.html
http://www.softwarepatch.com/windows/vbrun6.html
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe


4. Operation

FAR Out is a fairly simple program. In this section I will simply state what each menu choice does. Most menu choices have a corresponding toolbar button.

The File Menu

New - Clears all references to the currently open FAR file. Any pending operations (Add, Delete) will be lost since the file is not saved.

Open - Allows you to select a FAR file for Add, Delete and Extract operations.

Save - Saves changes to the currently open FAR file. All pending Add and Delete operations are performed as this time.

Exit - FAR Out terminates execution.

The Entries Menu

Add - Adds a single file to the currently open FAR file. If an existing file is not opened, the entry is added to a new FAR file. Entries that are added are marked with the [NEW] tag in the file list. The entries are not actually added to the file until the file is saved.

Add Directory - Adds the entire contents of a directory to the currently open far file. If an existing file is not opened, the entries are added to a new FAR file. Entries that are added are marked with the [NEW] tag in the file list. The entries are not actually added to the file until the file is saved.

Delete - Marks the files that are selected in the file entry list for later deletion. Entries that are selected are marked with the [DEL] tag in the file list. The entries are not actually deleted from the file until the file is saved. Newly added entries (marked with the [NEW] tag) that are deleted are simply removed from the file list.

Extract - Extracts the files that are selected in the file entry list. Any extraneous file directory information in the FAR directory is ignored.

Extract BMF to SKN - Extracts the selected files if they are BMF files and converts them to SKN format. The function will only extract BMF files and will ignore files of any other type.

Select All - Selects all of the entries in the currently open FAR file.

Undelete - Selected files that are marked for deletion will have the [DEL] tag removed. The files will no longer be deleted when the file is saved. Once the file is saved, the undelete function can not restore deleted files.

The File Entries List

The left-hand pane of the main window is the file entries list. Selecting a file on the file entries list will display at least a portion of the file's data in the data pane on the right. The format of the data displayed will vary based on the type of file selected.

Bitmap files will be displayed as images. Text files, SIF files and SKN files will be displayed as text. All other files will be displayed as a binary hex dump. Only the first 100 lines of a text file or the first 1600 bytes of other files will be displayed.

SUPPORT FOR "OPEN WITH"

You can double click a FAR file and choose to open it with FAR Out.
 - Double click a FAR file.
 - Click on the Other button.
 - Select the FAR Out program (Farout.exe) and click Open.

Double clicking a FAR file will now open it with FAR Out. :)

FIND AND F.NEXT BUTTONS (FIND FEATURE)

It is now possible to do a text based search for a file name. This is a partial match case insensitive search.

You perform a search by entering text into the search box above the file list. Click on the Find button to search for a match starting at the top of the list. If you find a match you can use the F.Next (find next) button to search again (for more matching files) starting at the current location in the list.

Partial match case insensitive search example: You enter the text skunk in the list. The files skunk.cmx, SKUNK.cfp and xskin-sKunK_smelly-STINK-BODY.skn would all match.

5. Support

You can find the FAR Out support forum at:
http://support.simwardrobe.com
(http://pub46.ezboard.com/bsimwardrobehome)