1. Introduction

SimWallCat is a program that will allow you to change the name price and description of walls and floors. Since The Sims sorts the wall and floors by price, the program can be used to determine the order that walls and floors appear in the game.


2. Legal Disclaimer

The software is provided strictly on an "as-is" basis, without any warranties of any kind, whether expressed or implied, including without limitation any warranties of merchantability, fitness for a particular purpose, non-infringement or compatibility with your computer hardware or software. The author has no liability of any kind or nature in connection with your use of the software (including without limitation liability for any consequential or incidental damages), and the entire risk of use (including without limitation any damage to your computer hardware or software) resides with you.


3. Installation

SimWallCat should be installed into a folder all by itself. Create a folder under The Sims, copy the file to and run it. It doesn't get any easier than that.

The program requires Visual Basic 6 runtime files. The VB 6 runtime files may be downloaded from the following locations:
http://www.tweakfiles.com/misc/vb6.html
http://www.softwarepatch.com/windows/vbrun6.html
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe

No additional files are required by SimWallCat.


4. Using SimWallCat

DO NOT USE THIS PROGRAM WHILE THE SIMS IS RUNNING!

In the upper left corner of the main window are two option buttons labeled "Edit Walls" and "Edit Floors". Clicking on one of these option buttons will display all of the folders inside the \walls or \floors folder in the folder selection list.

The next thing that you need to do is select a wall or floor folder. The folder selection list is in the upper left corner of the main window beneath the Edit Walls/Edit Floors option buttons. Selecting a folder causes the wall/floor selection panel (the giant square on the right) to populate with the walls or floors located in the selected folder.

The wall/floor selection panel displays the image and name of each wall/floor in the selected folder. If there are more than 49 walls or floors in the selected folder, the walls or floors will be displayed on multiple pages. The [Previous] and [Next] buttons below the wall/floor selection panel allow you to change the page displayed. The current page and number of pages is displayed in the text box between the [Previous] and [Next] buttons. The currently selected wall/floor is indicated by a flashing white rectangle. Clicking on the image of a wall or floor selects it.

Once an wall or floor is selected the filename is displayed in the Selected File Name box. The name, price and description of the wall or floor will appear in the Selected File Details box. A full size image of the selected wall or floor will also appear in the details box. Clicking the [Edit] button will load the selected wall or floor and display the editing window. Double clicking the image of a wall or floor in the selection panel will select it and cause it to be loaded immediately.

Note: SimWallCat is only able to see files and folders in the \Gamedata\Walls and \Gamedata\Floors folders.

The editing window is fairly simple. You can enter a new name, price and description for the wall or floor that you are editing. Clicking on the [Save] button will save your changes while clicking on the [Cancel] button will close the editing window without making any changes.


5. Support

You can find the SimWallCat support forum at:
http://support.simwardrobe.com


----------
Copyright (C) 2002 James A. Sausville. All rights reserved.
http://www.simwardrobe.com