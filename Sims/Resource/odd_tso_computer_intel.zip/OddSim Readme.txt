Thanks for downloading!

Extract all .iff and .far files to:
\Downloads\Odd\

If an entire folder is included, place the folder in:
\Downloads\Odd\

Please don't post my stuff anywhere else on the web.
It takes time to make quality products.
Please E-mail me your feedback!
NOTE: All my downloads have been updated for The Sims Makin' Magic.

You have permission to clone this object as long as proper credit is given. Put: "Original object by OddSim.com" in the discription and on the webpage, please. Also include this readme in the zip file. Be sure to tell me about your creation!

Thanks for downloading, and please visit my Web Site to check for new stuff!

Objects designed by OddSim
http://www.oddsim.com/
help@oddsim.com