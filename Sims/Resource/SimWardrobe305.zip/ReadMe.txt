1. Introduction

SimWardrobe is a program that was designed to fulfill a specific need. Specifically, I had a need to create new sims without spending half a day scrolling through my skin collection one outfit at a time. I have over 500 skins for light fit female sims alone.  This process was even more time consuming if I wanted to have custom swimsuit, formal and other skins. I knew there had to be a better way.

SimWardrobe allows you to do the following for each sim you have:

    - Select any body and matching skin for their normal outfit
    - Select any body and matching skin for their swimsuit
    - Select any body and matching skin for their formal outfit
    - Select any body and matching skin for their pajama outfit (Hot Date or newer)
    - Select any body and matching skin for their winter wear outfit (Vacation or newer)
    - Select any body and matching skin for their pajama outfit (Superstar or newer)
    - Select skins for their formal, normal open, normal point and normal closed hands.
    - Save and load sets of skins in ensemble files
    - Manage skins in FAR files

All bodies and skins are assign on a per sim basis. Changing the swimsuit body and skin for one sim does not affect the default swimsuit skin or the swimsuit skin of any other sim. 


2. Legal Disclaimer

The software is provided strictly on an "as-is" basis, without any warranties of any kind, whether expressed or implied, including without limitation any warranties of merchantability, fitness for a particular purpose, non-infringement or compatibility with your computer hardware or software. The author has no liability of any kind or nature in connection with your use of the software (including without limitation liability for any consequential or incidental damages), and the entire risk of use (including without limitation any damage to your computer hardware or software) resides with you.


3. Installation

The program will run successfully in any directory if you have the required VB runtime files. It should be installed in it's own directory as it does make several temporary files and optionally, a backup directory. I created a �programs� folder inside the sims folder and I keep SimWardrobe in it�s own folder inside of that.

The VB 6 runtime files may be downloaded from the following location:
http://download.microsoft.com/download/vb60pro/Redist/sp4/win98/EN-US/VBRun60sp4.exe

The only other file required by SimWardrobe is TABCTL32.OCX. This file should be located in the \windows\system directory.

Note: Some people were confused by the above text. Here is a short version of where I recommend you install SimWardrobe.

If The Sims in installed in:
 C:\Program Files\Maxis\The Sims
Then put SimWardrobe.exe in:
C:\Program Files\Maxis\The Sims\SimWardrobe

That's where I install it.


4. Using SimWardrobe (A Quasi-Tutorial)

DO NOT USE THIS PROGRAM WHILE THE SIMS IS RUNNING.

The first thing that you need to do is select a neighborhood. The neighborhood selection list is in the upper left corner of the main window. SimWardrobe will remember the last neighborhood selected and will display it the next time you run the program. Selecting a neighborhood causes the sim selection panel (the giant square on the right) to populate with the sims living in the selected neighborhood.

The sim selection panel displays the portrait and name of each sim in the selected neighborhood. If there are more than 49 sims in the selected neighborhood (both housed and unhoused), the sims will be displayed on multiple pages. The [Previous] and [Next] buttons below the sim selection panel allow you to change the page displayed. The current page and number of pages is displayed in the text box between the [Previous] and [Next] buttons. The currently selected sim is indicated by a flashing white rectangle. Clicking on a sim's portrait selects that sim.

If a sim's file cannot be successfully loaded, a large letter X on a red background will be displayed in place of the sim's portrait. A description of the problem encountered will be displayed in the lower left quadrant of the window if the damaged sim is selected. 

A question mark icon may be displayed in place of the portrait for some sims. All that this means is that the web image bitmap is missing from this sims file. Please see the known issues section for further details on this anomaly.

Once a sim is selected their name and several pictures of them will be displayed in the text box and picture box in the lower left quadrant of the window. Clicking the [Edit This Sim] button will close the window and load the selected sim. Double clicking a sims portrait in the selection panel will select the sim and cause it to be loaded immediately.

After a sim has been loaded, their portrait will be shown in the upper left corner of the edit sim window. Their name will be shown in a box to the right of this along with additional pictures of the sim. The skin selection tab group will also become visible.

The skin selection tab group has eight tabs, Normal, Swimsuit, Formal, Pajamas, Nude, Winter, High Fashion and Hands. The first seven tabs allow you to select any body and matching skin for use when that outfit is required (or selected) in the game. Clicking the [Change] button on any tab brings up the skin selection window. (Note: custom nudes were disabled by Maxis in unleashed and newer expansion packs)

The skin selection window allows you to select any body and matching skin for the outfit being changed. The bodies are listed in the upper left corner of the window in alphabetical order. Selecting a body causes the skin selection panel (the giant square on the right) to populate with skins that match the selected body.

The skin selection panel displays a thumbnail of each skin that matches the selected body. If there are more than 49 skins that match the selected body, the skins will be displayed on multiple pages. The [Previous] and [Next] buttons below the skin selection panel allow you to change the page displayed. The current page and number of pages is displayed in the text box between the [Previous] and [Next] buttons. The currently selected skin is indicated by a flashing white rectangle. Clicking on a skin's thumbnail selects that skin.

Once a skin is selected, it's name and a full size image will be displayed in the text box and picture box in the lower left quadrant of the window. Clicking the [Select] button will close the window and load the selected skin. Clicking the [Cancel] button will close the window without taking any action. Double clicking a skin's thumbnail in the selection panel will select the skin and cause it to be loaded immediately.

Version 3 of SimWardrobe can see skins that are in the skins folder as well as skins that are in FAR files. Both Maxis created FAR files and user created FAR files (in the textures folder) are scanned by SimWardrobe when the skin selection window is in FAR file mode. There are a pair of option buttons above the skin selection panel that allow you to instruct SimWardrobe to look for skins in FAR files.

The [Default] button on the skin selection tabs will return the outfit on the selected tab to it's in game default. The normal outfit does not have a default.

Select hand skins is almost identical to selecting an outfit. The select hand skin window does not have a model selection list.

There are some buttons on the hand tab that are not on the outfit tabs. The [Copy Left] button sets the right hand skin to be the same as the left hand skin. Most skins with separate hand skins use the identical bitmaps for both the left and right hands. The [Normal] button clears the formal hand skin fields. If the formal hand skin strings are blank, the normal hand skins will be used with the formal outfit. This is the default for male sims.

Version 3 of SimWardrobe only sees hand bitmaps that use the �standard� naming conventions. The valid file names for hand files have the following formats:

hm*.bmp
hf*.bmp
hu*.bmp
gm??_*.bmp
gf??_*.bmp
gu??_*.bmp


5. Managing Skins in FAR Files

Version 3 of SimWardrobe includes a very powerful new feature. You can import all of your skin BMP files into FAR file archives in the textures folder. Both SimWardrobe 3 and the game are capable of using the skins in these FAR files. You still put all your meshes into the skins folder, but all of the BMP files can now be placed into FAR files.

It is possible to have a truly large number of skins in the game through the use of FAR files. One of my beta testers loaded 2 GB of skins into The Sims this way. Multiple FAR files can be created for organizational purposes as well

From the Tools menu you can select �Manage Skins In FAR Files�. This will bring up the FAR file management window. This window allows you to create new FAR files and import BMP files into new or existing FAR files.

This window only manages FAR files in the Textures folder. It will only import BMP files. The mesh files (CMX and SKN) are still placed into the Skins folder.

The left side of the window allows you to manage FAR files. Above the Current FAR File text box is a row of three buttons. These buttons allow you to create a new FAR file, open an existing FAR file and save the current FAR file.

If the Current FAR File text box is blank, any BMP files that are added will be saved in a new FAR file. You will be prompted for a name when the new FAR file is saved.

When a FAR file is open you may search for a specific BMP file by using the search text box and the Find and F Next buttons. This is a partial match case-insensitive search.

You perform a search by entering text into the search box above the file list. Click on the Find button to search for a match starting at the top of the list. If you find a match you can use the F.Next (find next) button to search again (for more matching files) starting at the current location in the list.

Partial match case-insensitive search example: You enter the text �skunk� in the search box. The files skunk.bmp, SKUNK.BMP and smelly_skunk.bmp would all match.

The files in the current FAR file are listed in the file list box. Clicking on one of these files will display the file in the picture box below the list. When one or more of the files is selected they may be extracted by clicking on the extract files button located between the left and right panes of the window. (This is not a main feature of the window... but I decided to leave the functionality in place.)

Above the file list are two buttons that allow you to delete and undelete the files in the list that are selected. The files are not deleted until the file is saved.

The right hand panel of the FAR file management window allows you to find BMP files to import. You can select the drive and folder to look for files in with the drive combo and folder list at the top of the file selection panel. BMP files in the currently selected folder will be displayed in the file list. When you select a file in the file list a preview of that BMP will be displayed in the picture box below the file list. Click on the Add Selected Files button between the left and right panels to add the selected files to the current FAR file. You can also click on the Add Entire Folder button to add all the bitmaps in the selected folder to the current FAR file.

6. Virtual Ensembles

I had promised some type of ensemble option in SimWardrobe 2.0. What I came up with is a way to save all of the skins used on the sim being edited as a virtual ensemble file. The [Save] button in the Ensemble File frame will write out all of the skins in use by the active sim as a SimWardrobe Ensemble (SWE) file. Clicking on the [Load] button will load a selected SWE file and apply the skins to the sim being edited.

If you have a sims web site and you have Hot Date ensambles, you could make use of this option to provide a SWE file with your skins. This would allow people to put your skins into The Sims and then copy the SWE file to the SWE directory (inside of the folder where SimWardrobe is installed). They could then apply your ensemble to a sim with a single click using SimWardrobe. The SWE file is tiny so including it in the ZIP file won't add much to it's size.


7. Menu Options

Options Menu - Create Backup File

As you may have guessed, checking this will cause the user IFF file to be saved in a backup directory when changes to a sim are saved. The backup directory is created in the directory where SimWardrobe resides. The backup files have an informational name format. The file's name looks like this:
User00005.iff_Ima_UserData4_20010811_203333

From the above file name we can determine the following:
The original file name was User00005.iff
The sim's name is Ima.
The sim lives in neighborhood 4 (in \UserData4\Characters\)
The sim was saved on 8/11/2001 at 8:33PM. (the date time stamp on the file is not accurate because the file is a copy of the original user iff file and retains the original date time stamp)

To restore the above file:
Make sure the sims is not running.
Delete or move User0005.IFF from \UserData4\Characters\.
Copy the backup file to \UserData4\Characters\
Rename the file by deleting the first underscore character and every thing that follows it.

Options Menu - Set Path

Sometimes SimWardrobe can't find the path to The Sims (it should tell you). This menu choice will bring up the Set Path window. The Set Path window allows you to set the path to The Sims by hand.

Tools Menu - Export Skin Names

This option may be fairly useless to most of you, but I use it to find any sims with duplicate heads. (my party neighborhoods have 200+ sims!) All this option does is dump the names of the head skins and normal outfit skins to a text file. All of the sims in the currently selected neighborhood are listed in this file. The file is a semicolon-delimited file that can be easily imported into Excel. (I sort by skin name so the duplicates are listed together.)

Tools Menu - Fix Fit to Skinny Sims

This menu choice will go through every sim in the current neighborhood and will change their pajama, formal and swimsuit body type to match their normal body type. There is some kind of weird bug in Hot Date that will some fit sims skinny bodies for pajama, formal and swimsuit skins. This usually happens during townie creation.

Tools Menu - Manage Skins In FAR Files

Please see the section �Managing Skins in FAR Files� above.

Tools Menu - Remove Pink Gorilla Formal Hands

House party introduced a bug that gives sims pink gorilla hands for their formal hands. This bug was not fixed in Hot Date. This function will change the formal hands of all sims in the selected neighborhood to the correct formal defaults for their gender. It will only change the hands of sims with the pink problem (guao_pinkg).


8. Known Issues

Some Skin Files Can't Be Loaded

Visual Basic programs are unable to load some bitmap files. These files have an internal structure that causes the load to fail. SimWardrobe pre-loads all skin files before they are displayed in the skin selector. If files cause errors while loading, SimWardrobe will present you with a list of the files that it was unable to load. Loading these files in a program like Paint Shop Pro and re-saving them will "fix" the files.

Some Sims Have Missing Bitmaps

Some of the sims that are part of the original game have no web image bitmaps. These sims will display the question mark icon in SimWardrobe.

Both the Unleashed and Superstar expansion packs did not properly recreate the bitmaps for sims that were changed by SimMetamorphoser or other sims utility programs. These sims will always have the question mark icon as the game does not fix them right. The Makin Magic expansion pack does correct this and will recreate the bitmaps in the sims file again.

There is an extra issue with Superstar where simply changing your sims clothes in a dresser in the game will wipe out the bitmaps in the sims file. The Makin Magic expansion pack does not have this bug.


9. Q & A

Q: What guarantee do I have that your program won't mess up my sims?

A: In life there are no guarantees. I was extremely careful when creating this program. I did not want to mess up my own sims. The program loads and saves the user IFF files in the much same manner that The Sims does. The resource map is rebuilt properly when the file is saved. The old file is not altered in any way until the new file is written successfully. There is always the backup feature.

Q: Can I use the dresser or armoire in The Sims if I use your program?

A: Yes. You can use the dresser or armoire in The Sims to change into your sim's swimsuit, pajamas, formal and normal outfits. Using the "Change Clothes" option will undo all of the changes that you have made to the sim in SimWardrobe.


10. Support

You can find the SimWardrobe support forum at:
http://support.simwardrobe.com


