Lefty Sims Poker Set.

The Play Table requires Makin' Magic(MM)
The Table Requires House Party(HP)
Chair and Door require Living Large (LL)

Set Contains:
Door
Chair
1x2 Rug
Table
Poker Play Table
5 Walls
4 Floors



All rug images and part of two wall images are out of Mastertronic's Poker Academy game.

Rug made from my 1x2 Rug Base.


There is also a TWO part rug in to go with this set(has same image as the 1x2 Rug, but some prefere to have 2 Diffrent Rugs.)

There is also another wall and floor set to go with this set.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install far file in your Sims\Downloads folder.

Install Walls in Sims\GameData\Walls
Install Floors in Sims\Gamedata\Floors