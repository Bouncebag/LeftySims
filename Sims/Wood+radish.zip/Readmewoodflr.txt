floors

In Mahogany (to match table), white oak, cheery cherry and with a carpet in radish colour

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.

