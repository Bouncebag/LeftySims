Lefty's Sims Snake charmer AT home.

the snake chamer from makin' magic AT home

NOTE: cannot be deleted once placed and unpaused. choose positioning wisely

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
