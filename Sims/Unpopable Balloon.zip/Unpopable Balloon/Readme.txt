Lefty's Sims Unpopable Balloon.

Made from the "bust of Athena" object.

Just a T-mogged object.


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.