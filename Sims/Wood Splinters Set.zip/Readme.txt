Lefty Sims Wood Splinters Wall and floor Set.

Place Walls in Gamedata\Walls
Place Floors in Gamedata\Floors

Price $1

Downloaded from
http://uk.groups.yahoo.com/group/lefty_sims/