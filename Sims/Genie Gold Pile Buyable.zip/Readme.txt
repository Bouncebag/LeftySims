Lefty's Sims Buyable Genie Gold Pile.

The gold pile from the genie in Livin Large. Now buyable. 


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
