Lefty's Sims At Home Speakers.

The speakers on commecial Lots. AT home
the Green one the 'gothic' one and the grey one. all priced the same.

NOTE: you cannot control the music that is emmited from the speakers

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
