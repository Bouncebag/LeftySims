Lefty's Sims Maxis Matching Superstar Loveseat.

Requires HD, Matchs the Modern Sofa and chair that came with SuperStar.

created using the 2 end sprites of the Sofa.


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.