Lefty's Sims "Purpilll" "Orangeee" & "Bannanas" Inflatable Fun Chairs.

Outrageous! A fantastic, plastic, inflatable chair? Incredibly, these artsy, totally WACKY chairs actually work! Three new OUTRAGEOUS colors! An inexpensive and fun way to dress up your bedroom, dorm room, or anywhere you need a place to relax. Perfect for those with a little hot air to spare.

Comfort:3
Room:1


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.