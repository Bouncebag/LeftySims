Lefty's Sims Windows Inverted Blue.

Not boring old Wood New BLUE (inverted) windows.

Privacy Window AND Single Pane Window

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
