Lefty's Sims Blue Child Bed.

Does the Blue Bed not fit into your colour scheme? the red to bright? try our NEW light blue child bed with blue endtable.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
