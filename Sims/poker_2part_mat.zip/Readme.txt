This is the 2 part rug to go with my Poker Set.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install Objects in your Sims\Downloads folder.