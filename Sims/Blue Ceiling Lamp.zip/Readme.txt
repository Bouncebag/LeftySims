Lefty's Sims Blue Ceiling Lamp.

Santa Baena Ceiling Lamp in Blue.

Also comes in Permalamp variaty

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
