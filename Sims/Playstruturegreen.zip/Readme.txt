Lefty's Sims Green Playstruture.

The PlaySrruture But in green with purple slide.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
