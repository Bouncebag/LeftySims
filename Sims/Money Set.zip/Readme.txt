Lefty's Sims Money Set.

Made of MONEY. Like Money. if oyu are make your hygene and bladder rich with delight thanks to this set


Contains:
One Roman Bathtub (may require Livin Large?)
One Toilet (C&C interesting toilet)
Two Sinks one "counter" one and One free standing One.(Reqiures a expanion pack dont know which ones?)
One medicine cabinet (C&C Medicince cabinet)
One Counter
One Door.

C&C appropiate files (interesting Toilets and Medicince cabinet) are included with this download.

By Lefty Sims

http://uk.groups.yahoo.com/group/lefty_sims/

C&C stuff from http://c-and-c-enterprises.com