liugnonpcbookcase leftysims
To be used only by NPCs. Recreated by leftysims to tie in with more themes oringinal object here http://www.livin-it-up.net 

liugnonpchess  3.1
For use by NPCs only. modified to fit with the oringinal chess set by lefty sims oringinal here http://www.livin-it-up.net

liugnonpceasel leftysims
This easel can only be used by NPCs. Recreated by leftysims to tie in with more themes oringinal object here http://www.livin-it-up.net 

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.

all priced as oringinal
