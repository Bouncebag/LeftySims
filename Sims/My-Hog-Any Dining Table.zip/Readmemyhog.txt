My-Hog-Any

My-Hog-Any dining tables are the best in class for mhogany veneer tables straight from middle england, circa 1938 Made by leftysims

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.

priced at $259
