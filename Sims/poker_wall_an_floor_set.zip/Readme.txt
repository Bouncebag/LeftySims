Lefty Sims Wall and Floor Poker Set.



Set Contains:
5 Walls
2 Floors



All wall and floor images are out of Mastertronic's Poker Academy game.


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims


Install Walls in Sims\GameData\Walls
Install Floors in Sims\Gamedata\Floors