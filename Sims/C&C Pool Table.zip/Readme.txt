Lefty's Sims Maxis Matching C&C Pool Table.

Are you ready for C&C's Version of pool? Well get ready for your Sims to have lots of fun (including the kids) and Flock to your pool hall or bar! Recolor By Lefty Sims.


Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.


Oringinal Object by C&C enterprises.
http:// c-and-c-enterprises.com