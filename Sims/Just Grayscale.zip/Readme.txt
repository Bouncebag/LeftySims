Lefty Sims Grayscale Wall and floor Set.

Place Walls in Gamedata\Walls
Place Floors in Gamedata\Floors

Prices: $1
Names:
Just Black
Just Dark Grey
Just Light Grey
Just White

Downloaded from
http://uk.groups.yahoo.com/group/lefty_sims/