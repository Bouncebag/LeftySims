Lefty's Sims "Dark Side" Flamingo.

zero off all motives by viewing this object.
priced at $12
under misc. and deco.
Black with yellow beak.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
