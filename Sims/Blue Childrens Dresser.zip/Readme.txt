Lefty's Sims Blue Child Dresser.

Made to match the blue bed set.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
