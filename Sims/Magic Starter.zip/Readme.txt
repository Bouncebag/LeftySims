Lefty's Sims Magic Starter Kit.

the magic starter kit; BUYABLE.
priced at $1
under misc.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
