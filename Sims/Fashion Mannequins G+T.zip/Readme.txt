Lefty's Sims turquise and Green mannequins.

Fed up of having just ONE color mannequin avalible AND it's RED.
well, your problems are solved TWO new color Mannequins are 
avalible. turquise and Green.

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
