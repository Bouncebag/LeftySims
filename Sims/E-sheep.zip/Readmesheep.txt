E-Sheep Invasion

Wooly, furry desktop sheep are invading, try them here http://www.btinternet.com/~billericay.nw/site/SHEEP.HTM

Ahhh! Sheep. Leftysims creations

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.

priced at $13
