Lefty's Sims IJ Permalamp Blue.

These lamps stay on all night and all day.  This is nice if you don't like seeing dark rooms when your Sims are not in them.  If you want your Sims to sleep in a dark room then use normal lamps in their bedrooms.

In daylight, you shouldn't notice the lamps are still on, unless the room does not have enough windows, in which case the permanently on lamps will add a bit of cosy atmosphere.

Should work in any game version.

Oringal object by Inge Jones of simlogical.com

Downloaded from

http://uk.groups.yahoo.com/group/lefty_sims

install in your Sims\Downloads folder.
